/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.la_Ausflugsplaner;

import java.io.Serializable;
import java.util.ArrayList;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;


@Named(value = "Bean")
@ApplicationScoped
public class Bean implements Serializable {

    private String zeit;
    private String tag;
    private String wetter;
    private String kinder;
    private String schule;
    
    boolean kegeln, freibad, hallenbad, dunkelwald, musik, brotbackkurs, schieferbergwerk, gokurse, billard, rennauto, openair, korbflechten, wasserfall, zoobesuch;
    boolean tagsueber, wochentag, wetterschoen, ferien,  mitKindern;
    
    ArrayList<String> ausflug = new ArrayList<>();


    public ArrayList<String> getAusflug() {
        return ausflug;
    }

    public void setAusflug(ArrayList<String> ausflug) {
        this.ausflug = ausflug;
    }


    public void setTag(String tag) {
        this.tag = tag;
    }

    public void setWetter(String wetter) {
        this.wetter = wetter;
    }

    public void setSchule(String schule) {
        this.schule = schule;
    }

    public void setZeit(String zeit) {
        this.zeit = zeit;
    }

    public void setKinder(String kinder) {
        this.kinder = kinder;
    }

    public String getTag() {
        return tag;
    }

    public String getWetter() {
        return wetter;
    }

    public String getSchule() {
        return schule;
    }

    public String getZeit() {
        return zeit;
    }

    public String getKinder() {
        return kinder;
    }
    

    public String chooseAusflug(String result) {

        
        tagsueber = ("Tagsüber".equals(zeit));
        wetterschoen = ("schönes Wetter".equals(wetter));
        wochentag = ("Wochentag".equals(tag));
        ferien = ("Schulferien".equals(schule));
        mitKindern = ("Ausflug mit Kindern".equals(kinder));
        berechne();
        vorschlaegeAusgeben();
        return result;
    }

    private void berechne() {
        boolean abends = !tagsueber;
        boolean wochenEnde = !wochentag;
        boolean schlechtWetter = !wetterschoen;
        boolean schulzeit = !ferien;
        boolean nurErwachsene = !mitKindern;

        kegeln = abends || wochenEnde;
        freibad = wetterschoen && tagsueber;
        hallenbad = !(ferien && wochenEnde);
        dunkelwald = freibad;
        musik = abends && schulzeit;
        brotbackkurs = wochenEnde && schlechtWetter;
        schieferbergwerk = tagsueber || (wochenEnde && ferien);
        gokurse = (wochenEnde && schlechtWetter) || (wochentag && abends && wetterschoen);
        billard = nurErwachsene && (abends || wochenEnde);
        rennauto = nurErwachsene && tagsueber && ferien && wochenEnde;
        openair = wetterschoen && (abends || wochenEnde);
        korbflechten = ferien && schlechtWetter && wochentag;
        wasserfall = tagsueber;
        zoobesuch = true;
    }

    private void vorschlaegeAusgeben() {
        if (kegeln) {
            ausflug.add("Kegeln");
        }
        if (freibad) {
            ausflug.add("Freibad");
        }
        if (hallenbad) {
            ausflug.add("Hallenbad");
        }
        if (dunkelwald) {
            ausflug.add("Dunkelwald");
        }
        if (musik) {
            ausflug.add("Musikkurs");
        }
        if (brotbackkurs) {
            ausflug.add("Brotbackkurs");
        }
        if (schieferbergwerk) {
            ausflug.add("Schieferbergwerk");
        }
        if (gokurse) {
            ausflug.add("Go Kurse");
        }
        if (billard) {
            ausflug.add("Billard");
        }
        if (rennauto) {
            ausflug.add("Rennauto");
        }
        if (openair) {
            ausflug.add("Open Air Kino");
        }
        if (korbflechten) {
            ausflug.add("Korbflechten");
        }
        if (wasserfall) {
            ausflug.add("Wasserfall");
        }
        if (zoobesuch) {
            ausflug.add("Zoobesuch");
        }
    }


}
